


/* I tried to write the JS code here but that was not working so I added at the end of html page
* Please check in html page bottom.
*
* 1) OnClick event for "Sign In" link at top right corner. A modal will open after clicking on Sign in link/button.
* 2) Added onmouseover and onmouseout events in "Breaking news" alert box (Changing box/div color)
*
* */