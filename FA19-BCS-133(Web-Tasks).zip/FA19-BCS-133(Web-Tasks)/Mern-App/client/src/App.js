import './App.css';
import { createBrowserRouter, Outlet, RouterProvider } from "react-router-dom"
import { useContext } from 'react';
import { AuthContext } from './context/authContext';
import Login from './pages/Login';
import Home from './pages/Home';
import Register from './pages/Register';
import Header from './components/Header';
import AdminMenu from "./components/AdminMenu";
import TierList from './pages/TierList';
import Tier1 from './pages/Tier1';
import Tier2 from './pages/Tier2';
import Tier3 from './pages/Tier3';
import Tier4 from './pages/Tier4';
import Tier5 from './pages/Tier5';
import AdminDashboard from './pages/admin/AdminDashboard';
import Buttons from './pages/admin/Buttons';
import Text from './pages/admin/Text';
import Memes from './pages/admin/Memes';
import Tiers from './pages/admin/Tiers';
import AddNewMeme from './pages/admin/AddNewMeme';
import EditMeme from "./pages/admin/EditMeme";



function App() {

  const { currentUser, role } = useContext(AuthContext)
  console.log(role);

  const RequireLoginLayout = () => {
    return (
      currentUser ? <>
        <Header></Header>
        <Outlet />
      </> : <Register></Register>
    )
  }

  const RequireAdminLayout = () => {
    return (
      role === "admin" ? <>
        <section className='flex items-stretch h-full w-full'>
          <AdminMenu />
          <Outlet />
        </section>
      </> : <Login></Login>
    )
  }

  const router = createBrowserRouter([
    {
      path: "/",
      element: <RequireLoginLayout />,
      children: [
        {
          path: "/",
          element: <Home />,
        },
        {
          path: "/home",
          element: <Home />,
        },
        {
          path: "/tier-list",
          element: <TierList />,
        },
        {
          path: "/tier-1",
          element: <Tier1 />
        },
        {
          path: "/tier-2",
          element: <Tier2 />,
        },
        {
          path: "/tier-3",
          element: <Tier3 />,
        },
        {
          path: "/tier-4",
          element: <Tier4 />,
        },
        {
          path: "/tier-5",
          element: <Tier5 />,
        }
      ]
    },
    {
      path: "/admin",
      element: <RequireAdminLayout />,
      children: [
        {
          path: "/admin",
          element: <AdminDashboard />
        },
        {
          path: "/admin/buttons",
          element: <Buttons />
        },
        {
          path: "/admin/text",
          element: <Text />
        },
        {
          path: "/admin/memes",
          element: <Memes />
        },
        {
          path: "/admin/tiers",
          element: <Tiers />
        },
        {
          path: "/admin/addNewMeme",
          element: <AddNewMeme />
        },
        {
          path: "/admin/editMeme/:id",
          element: <EditMeme />
        },
      ]
    },
    {
      path: "/register",
      element: <Register></Register>
    },
    {
      path: "/login",
      element: <Login></Login>
    }
  ])


  return (
    <main>
      <RouterProvider router={router}>
      </RouterProvider>
    </main>
  );
}

export default App;
