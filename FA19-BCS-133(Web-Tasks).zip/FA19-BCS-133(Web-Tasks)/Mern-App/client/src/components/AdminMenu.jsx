import React from 'react'
import { Link } from 'react-router-dom'


const styles = {
    linkStyle: {
        borderBottom: "1px solid #DDDDDD",
        padding: "12px 4px"
    }
}


const AdminMenu = () => {
    return (
        <div style={{ maxWidth: "220px", width: "100%", height: "100vh", boxShadow: "2px 0 4px rgba(0, 0, 0, 0.67)", padding: "25px", display: "flex", flexDirection: "column", gap: "10px" }}>
            <div>
                <h2 className='text-xl mb-6'>MemerHub Online</h2>
            </div>
            <Link to="/admin/buttons" style={styles.linkStyle}>Buttons</Link>
            <Link to="/admin/text" style={styles.linkStyle}>Text</Link>
            <Link to="/admin/memes" style={styles.linkStyle}>Memes</Link>
            <Link to="/admin/tiers" style={styles.linkStyle}>Tiers</Link>
        </div>
    )
}

export default AdminMenu