import React, { useState, useEffect, useContext } from 'react'
import { GiHamburgerMenu } from "react-icons/gi"
import { AiOutlineUser } from 'react-icons/ai'
import { GrClose, GrNotification } from "react-icons/gr"
import { AuthContext } from '../context/authContext'
import axios from 'axios'
import { Link } from "react-router-dom"
import { ModalContext } from "../context/modalContext"
import { SiteInfoContext } from '../context/siteInfoContext'


const Header = () => {

    const { currentUser, logout, role } = useContext(AuthContext)
    const { showModal, setShowModal } = useContext(ModalContext)
    const { API_URL } = useContext(SiteInfoContext)

    const [showMenu, setShowMenu] = useState(false)
    const [showNotification, setShowNotification] = useState(false)
    const [showProfile, setShowProfile] = useState(false)
    const [notification, setNotification] = useState([])
    const [domainName, setDomainName] = useState('')


    useEffect(() => {
        const getNotification = async () => {
            try {
                const res = await axios.get(`${API_URL}/api/notification`, {
                    headers: {
                        authorization: `Bearer ${currentUser?.token}`
                    }
                })
                setNotification(res.data)
            } catch (error) {
                console.log(error.message);
            }
        }
        getNotification()
        // console.log(currentUser)
    }, [currentUser, API_URL])

    useEffect(() => {
        setDomainName(window.location.origin)
    }, [])

    const handleCopyToClipboard = async (e) => {
        const copyText = document.getElementById("invitation_link")
        copyText.select()
        // copyText.setSelectionRange(0, 99999);
        await navigator.clipboard.writeText(copyText.value);
        // alert("Copied the text: " + copyText.value);
        e.target.innerText = "Copied!"
    }


    return (
        <>
            <header>
                <div className="container mx-auto px-3 md:px-0 py-3 flex justify-between items-center">
                    <div className="menu">
                        <button>
                            <GiHamburgerMenu className="text-3xl" onClick={() => setShowMenu(!showMenu)} />
                        </button>

                        {
                            showMenu && <>
                                <div className="absolute top-0 left-0 w-full max-w-[220px] p-4 bg-slate-100 h-screen">
                                    <div className="flex justify-between gap-5 items-center mb-5">
                                        <span></span>
                                        <span className='text-lg'>
                                            {currentUser?.username}
                                        </span>
                                        <span className='cursor-pointer' onClick={() => setShowMenu(!showMenu)}>
                                            <GrClose className='text-2xl' />
                                        </span>
                                    </div>
                                    <div className="my-6">
                                        <div className="flex justify-between items-center py-2 border-b-2 border-b-slate-500 flex-wrap">
                                            <span>User id</span>
                                            <span className='text-xs'>{currentUser?._id}</span>
                                        </div>
                                        <div className="flex justify-between items-center py-2 border-b-2 border-b-slate-500">
                                            <span>Tier</span>
                                            <span>{currentUser?.tier}</span>
                                        </div>
                                        <div className="flex justify-between items-center py-2 border-b-2 border-b-slate-500">
                                            <span>Invites</span>
                                            <span>{currentUser?.invited}</span>
                                        </div>
                                    </div>
                                    <div className='flex flex-col gap-2'>
                                        {role === "admin" && <>
                                            <Link to="/admin" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                                Admin
                                            </Link>
                                        </>}
                                        <Link to="/" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Home
                                        </Link>
                                        <button onClick={() => setShowModal("invites")} className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Invites
                                        </button>
                                        <Link to="/tier-list" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Tier List
                                        </Link>
                                        <Link to="/tier-1" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Tier 1
                                        </Link>
                                        <Link to="/tier-2" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Tier 2
                                        </Link>
                                        <Link to="/tier-3" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Tier 3
                                        </Link>
                                        <Link to="/tier-4" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Tier 4
                                        </Link>
                                        <Link to="/tier-5" className='border-slate-700 border-2 rounded-xl bg-slate-200 text-xl w-full py-1 text-center'>
                                            Tier 5
                                        </Link>
                                    </div>
                                </div>
                            </>
                        }

                    </div>
                    <div className="profile relative">
                        <button>
                            <GrNotification className="text-2xl mr-3" onClick={() => setShowNotification(!showNotification)} />
                        </button>
                        {
                            showNotification && <>
                                <div className="absolute top-10 right-0 w-[250px] h-fit p-4 rounded-2xl bg-slate-100 shadow-lg">
                                    <div className="flex justify-between gap-5 items-center mb-5">
                                        <span className='text-lg'>
                                            Notification
                                        </span>
                                        <span className='cursor-pointer'>
                                            <GrClose className='text-2xl' onClick={() => setShowNotification(!showNotification)} />
                                        </span>
                                    </div>
                                    <div className="max-h-[400px] h-full overflow-y-scroll bg-white p-1 rounded">

                                        {
                                            notification.length ? <>
                                                {
                                                    notification.map(noti => (
                                                        <div className="p-1 rounded my-2" style={{ background: noti.bgColor }} key={noti._id}>
                                                            <span className='text-sm'>{noti.msg}</span>
                                                        </div>
                                                    ))
                                                }
                                            </> : <>
                                                <div className="bg-slate-100 p-2 rounded my-1 text-center">
                                                    <span className='font-semibold'>Not Notification Found</span>
                                                </div>
                                            </>
                                        }

                                    </div>
                                </div>
                            </>
                        }
                        <button>
                            <AiOutlineUser className="text-3xl" onClick={() => setShowProfile(!showProfile)} />
                        </button>
                        {
                            showProfile && <>
                                <div className="absolute top-10 right-0 w-[250px] h-fit p-4 rounded-2xl bg-slate-100 shadow-lg">
                                    <div className="flex justify-between gap-5 items-center mb-5">
                                        <span className='cursor-pointer'>
                                            <GrClose className='text-2xl' onClick={() => setShowProfile(!showProfile)} />
                                        </span>
                                        <span className='text-lg'>
                                            {currentUser?.username}
                                        </span>
                                        <span></span>
                                    </div>
                                    <div className='flex items-center justify-between gap-2 mb-2'>
                                        <span className='text-md'>Invites:</span> <span className='text-xl'>{currentUser?.invited}</span>
                                    </div>
                                    <div className='flex items-center justify-between gap-2 mb-2 flex-wrap'>
                                        <span className='text-md'>User Id:</span> <span className='text-xs'>{currentUser?._id}</span>
                                    </div>
                                    <div className="logout">
                                        <button className="py-1 px-5 bg-red-500 text-white rounded-lg"
                                            onClick={() => logout()}
                                        >Logout</button>
                                    </div>
                                </div>
                            </>
                        }
                    </div>
                </div>
            </header>

            {
                showModal && <section className="modal-section fixed top-[50%] left-0 right-0 w-full h-[50vh] px-4" >
                    <div className="container mx-auto rounded-t-3xl h-full w-full p-6 relative" style={{ background: "rgba(0, 0, 0, 0.5)" }}>
                        <div className="flex justify-end absolute top-8 right-8">
                            <button onClick={() => setShowModal(null)}>
                                <GrClose className='text-2xl' />
                            </button>
                        </div>

                        {
                            showModal === "invites" && <div className="h-full w-full bg-white rounded-t-3xl shadow-xl">
                                <h1 className='text-center md:text-5xl text-2xl font-semibold'>You have invited</h1>
                                <h2 className='text-center md:text-3xl text-xl font-semibold'>{currentUser?.invited} Person</h2>
                            </div>
                        }
                        {
                            showModal === "invitation_link" && <div className="h-full w-full bg-white rounded-t-3xl shadow-xl">
                                <div className="flex justify-center items-center flex-col gap-3">
                                    <h1 className="font-semibold text-4xl md:text-2xl">Your invitation Link is below</h1>
                                    <div className='flex gap-5 justify-between items-center max-w-[670px] w-full flex-wrap'>
                                        <input type="text" value={`${domainName}/register?invitedFrom=${currentUser?._id}`} readOnly className='max-w-xl w-full bg-slate-700 text-white outline-none py-3 px-7 rounded text-md' id="invitation_link" />
                                        <span className='bg-slate-600 text-white rounded-lg shadow-lg py-2 px-6 text-sm cursor-pointer' title='Copy to clipboard' onClick={handleCopyToClipboard}>Copy</span>
                                    </div>
                                    <p className="md:text-xl text-lg">Please share this link</p>
                                </div>
                            </div>
                        }

                    </div>
                </section>
            }
        </>
    )
}

export default Header