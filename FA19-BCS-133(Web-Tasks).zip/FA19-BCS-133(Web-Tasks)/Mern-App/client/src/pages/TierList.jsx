import React, { useContext } from 'react'
import { AuthContext } from '../context/authContext'
import { ModalContext } from '../context/modalContext'
import { SiteInfoContext } from '../context/siteInfoContext'

const TierList = () => {

    const { currentUser } = useContext(AuthContext)
    const { setShowModal } = useContext(ModalContext)
    const { buttons, siteText } = useContext(SiteInfoContext)

    return (
        <section className="my-3">
            <div className="container mx-auto px-3 md:px-0">
                <div className="max-w-2xl w-full mx-auto">
                    <div className="bg-gray-200 rounded shadow p-4 my-4">
                        <h2 className="text-2xl">{siteText?.tier1Heading}</h2>
                        <p className="text-lg">{siteText?.tier1Subheading}</p>
                        {
                            currentUser?.tier < 1 && <>
                                <button onClick={() => setShowModal("invitation_link")} className=" bg-sky-600 text-white rounded-3xl py-1 px-6 mr-3">{buttons?.inviteButtonText}</button>
                                <a href={buttons?.instantAccessButtonLink} target="_blank" rel='noreferrer' className="bg-pink-600 text-white rounded-3xl py-1 px-6">{buttons?.instantAccessButtonText}</a>
                            </>
                        }
                    </div>
                    <div className="bg-gray-200 rounded shadow p-4 my-4">
                        <h2 className="text-2xl">{siteText?.tier2Heading}</h2>
                        <p className="text-lg">{siteText?.tier2Subheading}</p>
                        {
                            currentUser?.tier < 2 && <>
                                <button onClick={() => setShowModal("invitation_link")} className=" bg-sky-600 text-white rounded-3xl py-1 px-6 mr-4">{buttons?.inviteButtonText}</button>
                                <a href={buttons?.instantAccessButtonLink} target="_blank" rel='noreferrer' className="bg-pink-600 text-white rounded-3xl py-1 px-6">{buttons?.instantAccessButtonText}</a>
                            </>
                        }
                    </div>
                    <div className="bg-gray-200 rounded shadow p-4 my-4">
                        <h2 className="text-2xl">{siteText?.tier3Heading}</h2>
                        <p className="text-lg">{siteText?.tier3Subheading}</p>
                        {
                            currentUser?.tier < 3 && <>
                                <button onClick={() => setShowModal("invitation_link")} className=" bg-sky-600 text-white rounded-3xl py-1 px-6 mr-3">{buttons?.inviteButtonText}</button>
                                <a href={buttons?.instantAccessButtonLink} target="_blank" rel='noreferrer' className="bg-pink-600 text-white rounded-3xl py-1 px-6">{buttons?.instantAccessButtonText}</a>
                            </>
                        }
                    </div>
                    <div className="bg-gray-200 rounded shadow p-4 my-4">
                        <h2 className="text-2xl">{siteText?.tier4Heading}</h2>
                        <p className="text-lg">{siteText?.tier4Subheading}</p>
                        {
                            currentUser?.tier < 4 && <>
                                <button onClick={() => setShowModal("invitation_link")} className=" bg-sky-600 text-white rounded-3xl py-1 px-6 mr-3">{buttons?.inviteButtonText}</button>
                                <a href={buttons?.instantAccessButtonLink} target="_blank" rel='noreferrer' className="bg-pink-600 text-white rounded-3xl py-1 px-6">{buttons?.instantAccessButtonText}</a>
                            </>
                        }
                    </div>
                    <div className="bg-gray-200 rounded shadow p-4 my-4">
                        <h2 className="text-2xl">{siteText?.tier5Heading}</h2>
                        <p className="text-lg">{siteText?.tier5Subheading}</p>
                        {
                            currentUser?.tier < 5 && <>
                                <button onClick={() => setShowModal("invitation_link")} className=" bg-sky-600 text-white rounded-3xl py-1 px-6 mr-3">{buttons?.inviteButtonText}</button>
                                <a href={buttons?.instantAccessButtonLink} target="_blank" rel='noreferrer' className="bg-pink-600 text-white rounded-3xl py-1 px-6">{buttons?.instantAccessButtonText}</a>
                            </>
                        }
                    </div>
                </div>
            </div>
        </section>
    )
}

export default TierList