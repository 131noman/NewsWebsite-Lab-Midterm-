import axios from 'axios'
import React, { useContext, useState, useEffect } from 'react'
import { AuthContext } from '../context/authContext'
import { ModalContext } from '../context/modalContext'
import { SiteInfoContext } from '../context/siteInfoContext'

const Home = () => {

    const { currentUser } = useContext(AuthContext)
    const { setShowModal } = useContext(ModalContext)
    const { buttons, API_URL, siteText } = useContext(SiteInfoContext)
    const [memes, setMemes] = useState([])
    const [page, setPage] = useState(0)
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        const getMemes = async () => {
            if (currentUser?.tier > 0) {
                const res = await axios.get(`${API_URL}/api/media?skip=${page}&limit=5`, {
                    headers: {
                        authorization: `Bearer ${currentUser?.token}`
                    }
                })
                setMemes(prev => [...prev, ...res.data])
                setLoading(false)
            }
        }
        getMemes()
    }, [currentUser, page, API_URL])

    const handleScroll = () => {
        if (window.innerHeight + document.documentElement.scrollTop + 1 >= document.documentElement.scrollHeight) {
            setLoading(true)
            setPage(prev => prev + 5)
        }
    }

    useEffect(() => {
        window.addEventListener("scroll", handleScroll)

        return () => window.removeEventListener("scroll", handleScroll)
    }, [])


    return (
        <section className="meme-section">
            <div className="container mx-auto px-3 md:px-0">
                <h2 className="text-lg text-center">{siteText?.homePageText1} {currentUser?.username}</h2>
                {
                    currentUser?.tier < 5 ? <>
                        <h1 className='text-2xl font-semibold text-center max-w-sm mx-auto'>
                            {siteText?.homePageText2}
                        </h1>
                        <div className="w-fit mx-auto my-5">
                            <button onClick={() => setShowModal("invitation_link")} className='bg-sky-600 text-white text-lg py-1 px-6 rounded-2xl mr-4'>{buttons?.inviteButtonText}</button>
                            <a href={buttons?.instantAccessButtonLink} target="_blank" rel='noreferrer' className="bg-pink-600 text-white rounded-3xl py-1 px-6">{buttons?.instantAccessButtonText}</a>
                        </div>
                    </> : <>
                        <h1 className='text-2xl font-semibold text-center my-5 max-w-sm mx-auto'>
                            {siteText?.homePageText3}
                        </h1>
                    </>
                }
                <div className='my-5'>
                    <h2 className="text-center text-2xl">{siteText?.homePageText4}</h2>
                </div>
                <div className="max-w-2xl w-full mx-auto">
                    {
                        memes.length && memes.map(meme => (
                            <div className="bg-slate-600 p-3 rounded shadow my-2" key={meme._id}>
                                {
                                    meme.type === "image" && <img className="w-full h-fit rounded" src={`${API_URL}/${meme.path + meme.url}`} alt={meme.name} />
                                }
                                {
                                    meme.type === "video" && <video src={`${API_URL}/${meme.path + meme.url}`} className="w-full h-fit rounded" controls></video>
                                }
                            </div>
                        ))
                    }
                    {
                        loading && <div className="text-center mx-auto w-[100px]">
                            <button className='gap-2 w-[50px] h-[50px] rounded-full shadow-lg animate-spin  flex items-center justify-between flex-col '>
                                <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                                <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                                <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                                <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                            </button>
                        </div>
                    }
                </div>
            </div>
        </section >
    )
}

export default Home