import React, { useState, useContext } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { AuthContext } from '../context/authContext'

const Register = () => {

    const [error, setError] = useState(null)
    const search = useLocation().search.split("=")[1]
    const invitedFrom = search ? search : null
    const { register } = useContext(AuthContext)
    const navigate = useNavigate()

    const handleSubmit = async (e) => {
        e.preventDefault()

        const username = e.target.username.value
        const password = e.target.password.value

        try {
            await register({ username, password, invitedFrom })
            navigate("/home");
        } catch (error) {
            setError(error.response.data.message)
        }

    }


    return (
        <section className="login bg-slate-700 ">
            <div className="container mx-auto px-3 md:px-0">
                <div className="flex justify-center items-center h-screen w-full">
                    <div className="">
                        <h2 className="text-center mb-4 text-white text-2xl font-semibold">Please Register Now</h2>
                        <form className='p-8 shadow rounded-md max-w-sm w-full bg-slate-400' onSubmit={handleSubmit}>
                            {error && <p className='text-center text-lg text-red-700 mb-3'>{error}</p>}

                            <input type="text" name='username' className='outline-none py-2 px-3 rounded text-sm mb-3 w-full' placeholder='username' />
                            <input type="password" name='password' className='outline-none py-2 px-3 rounded text-sm mb-3 w-full' placeholder='password' />
                            <button className="w-full text-center rounded shadow bg-black text-white py-2 px-3 hover:bg-teal-700 transition-all my-5">Register</button>
                            <p>Have you an account? <Link to={`/login${search ? `?invitedFrom=${search}` : ""}`} className='text-red-600 underline'>Login here!</Link></p>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Register