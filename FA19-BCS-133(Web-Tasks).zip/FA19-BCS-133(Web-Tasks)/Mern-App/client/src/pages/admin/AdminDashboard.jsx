import React from 'react'

const AdminDashboard = () => {
    return (
        <div className='flex flex-1 justify-center items-center h-auto w-full bg-slate-500'>
            <h1 className='text-3xl text-slate-50'>AdminDashboard</h1>
        </div>
    )
}

export default AdminDashboard