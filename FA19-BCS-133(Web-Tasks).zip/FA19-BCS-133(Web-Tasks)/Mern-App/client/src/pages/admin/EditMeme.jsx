import axios from 'axios'
import React, { useContext, useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { SiteInfoContext } from '../../context/siteInfoContext'

const EditMeme = () => {

    const [memeInfo, setMemeInfo] = useState({ name: "", tier: "", type: "", path: "", url: "" })
    const { API_URL } = useContext(SiteInfoContext)
    const { id } = useParams()

    const handleSubmit = async (e) => {
        e.preventDefault()

        const res = await axios.put(`${API_URL}/api/media/${id}`, { ...memeInfo })
        if (res.data) {
            e.target.reset()
            alert("Meme updated")
        }
        else {
            alert('Something went wrong')
        }
    }

    useEffect(() => {
        const getMeme = async () => {
            const res = await axios.get(`${API_URL}/api/media/single/${id}`)
            if (res.data) {
                setMemeInfo(res.data)
            }
        }
        getMeme()
    }, [id, API_URL])


    return (
        <section className="memes-section p-4 flex justify-center items-center bg-slate-600 w-full">
            <div className='max-w-[449px] bg-slate-50 p-5 rounded shadow'>
                <form action="" onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <h2 className='text-center text-xl'>Edit the Meme</h2>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            Name
                        </label>
                        <input type="text" className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='name' value={memeInfo?.name} onChange={(e) => setMemeInfo({ ...memeInfo, [e.target.name]: e.target.value })} />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            Tier
                        </label>
                        <select className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='tier' value={memeInfo?.tier} onChange={(e) => setMemeInfo({ ...memeInfo, [e.target.name]: e.target.value })}>
                            <option value="1" selected={memeInfo?.tier === 1 ? true : false}>1</option>
                            <option value="2" selected={memeInfo?.tier === 2 ? true : false}>2</option>
                            <option value="3" selected={memeInfo?.tier === 3 ? true : false}>3</option>
                            <option value="4" selected={memeInfo?.tier === 4 ? true : false}>4</option>
                            <option value="5" selected={memeInfo?.tier === 5 ? true : false}>5</option>
                        </select>
                    </div>
                    {/* <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            Type
                        </label>
                        <select className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='type' onChange={(e) => setMemeInfo({ ...memeInfo, [e.target.name]: e.target.value })} >
                            <option value="image" selected={memeInfo?.type === "image" ? true : false}>Image</option>
                            <option value="video" selected={memeInfo?.type === "video" ? true : false}>Video</option>
                        </select>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            Please choose an image or video
                        </label>
                        <input type="file" className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='file' />
                    </div> */}
                    <div className="mt-6">
                        <button className="w-full py-2 px-4 rounded shadow bg-teal-600 text-slate-50 text-lg">Add Meme</button>
                    </div>
                </form>
            </div>
        </section>
    )
}

export default EditMeme