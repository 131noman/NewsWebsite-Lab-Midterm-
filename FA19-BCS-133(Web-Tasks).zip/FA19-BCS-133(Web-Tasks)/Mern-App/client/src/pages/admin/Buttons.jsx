import React, { useState, useEffect, useContext } from 'react'
import { SiteInfoContext } from '../../context/siteInfoContext'

const Buttons = () => {

    const [buttonInfo, setButtonInfo] = useState({ inviteButtonText: "", instantAccessButtonText: "", instantAccessButtonLink: "" })

    const { buttons, updateButtons } = useContext(SiteInfoContext)

    const handleClick = async () => {
        await updateButtons(buttonInfo)
        alert("Button Updated")
    }
    useEffect(() => {
        setButtonInfo(buttons)
    }, [buttons])

    return (
        <section className="buttons p-4 flex justify-center items-center bg-slate-600 w-full">
            <div className='max-w-[449px] bg-slate-50 p-5 rounded shadow'>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Invite Button Text
                    </label>
                    <input type="text" placeholder='' value={buttonInfo.inviteButtonText} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='inviteButtonText' onChange={(e) => setButtonInfo({ ...buttonInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Instant Access Button Text
                    </label>
                    <input type="text" placeholder='' value={buttonInfo.instantAccessButtonText} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='instantAccessButtonText' onChange={(e) => setButtonInfo({ ...buttonInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Instant Access Button Link
                    </label>
                    <input type="text" placeholder='' value={buttonInfo.instantAccessButtonLink} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='instantAccessButtonLink' onChange={(e) => setButtonInfo({ ...buttonInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mt-6">
                    <button className="w-full py-2 px-4 rounded shadow bg-teal-600 text-slate-50 text-lg" onClick={handleClick}>Change Now</button>
                </div>
            </div>
        </section>
    )
}

export default Buttons