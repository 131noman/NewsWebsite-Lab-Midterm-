import axios from 'axios'
import React, { useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { AuthContext } from '../../context/authContext'
import { SiteInfoContext } from '../../context/siteInfoContext'

const Memes = () => {

    const { currentUser } = useContext(AuthContext)
    const { API_URL } = useContext(SiteInfoContext)
    const [memes, setMemes] = useState([])
    const [page, setPage] = useState(0)

    useEffect(() => {
        const getMemes = async () => {
            const res = await axios.get(`${API_URL}/api/media/all?skip=${page}&limit=9`)
            setMemes(prev => [...prev, ...res.data])
        }
        getMemes()
    }, [currentUser, page, API_URL])

    const handleScroll = () => {
        if (window.innerHeight + document.documentElement.scrollTop + 1 >= document.documentElement.scrollHeight) {
            setPage(prev => prev + 6)
        }
    }

    useEffect(() => {
        window.addEventListener("scroll", handleScroll)
        return () => window.removeEventListener("scroll", handleScroll)
    }, [])

    const handleDelete = async (id) => {
        await axios.delete(`${API_URL}/api/media/${id}`)
        setMemes(memes.filter(meme => meme._id !== id))
        alert("Meme Deleted Successfully")
    }


    return (
        <section className="memes-section p-5">
            <div className='mb-4'>
                <Link to="/admin/addNewMeme" className='bg-teal-600 text-slate-50 py-2 px-5 rounded'>Add New Meme <span className='text-xl'>+</span></Link>
            </div>
            <div className="memes grid grid-cols-3 gap-5">
                {
                    memes.length && memes?.map(meme => (
                        <>
                            <div className="meme shadow rounded p-3" key={meme._id}>
                                <div>
                                    {
                                        meme.type === "image" && <img className="w-full rounded" style={{ maxHeight: "250px", objectFit: "cover" }} src={`${API_URL}/${meme.path + meme.url}`} alt={meme.name} />
                                    }
                                    {
                                        meme.type === "video" && <video src={`${API_URL}/${meme.path + meme.url}`} className="w-full rounded" style={{ maxHeight: "250px", objectFit: "cover" }} controls></video>
                                    }
                                </div>
                                <div>
                                    <h2 className='text-md font-semibold'>{meme.name}</h2>
                                </div>
                                <div className="flex gap-4 justify-between items-center mt-2">
                                    <Link to={`/admin/editMeme/${meme._id}`} className='bg-yellow-600 text-white py-1 px-3 rounded'>Edit</Link>
                                    <button className='bg-red-600 text-white py-1 px-3 rounded' onClick={() => handleDelete(meme._id)}>Delete</button>
                                </div>
                            </div>
                        </>
                    ))
                }
            </div>
        </section>
    )
}

export default Memes