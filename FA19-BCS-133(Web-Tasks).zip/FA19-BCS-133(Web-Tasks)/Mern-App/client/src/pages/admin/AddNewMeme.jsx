import axios from 'axios'
import React from 'react'
import { useContext } from 'react'
import { SiteInfoContext } from '../../context/siteInfoContext'

const AddNewMeme = () => {

    const { API_URL } = useContext(SiteInfoContext)

    const upload = async (type, file) => {
        try {
            const formData = new FormData()
            formData.append("file", file)
            const res = await axios.post(`${API_URL}/api/upload/${type === "image" ? "image" : "video"}`, formData)
            return res.data
        } catch (error) {
            console.log(error)
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault()

        if (e.target.file.value.length < 1) {
            return alert("Please add file")
        }

        const fileUrl = await upload(e.target.type.value, e.target.file.files[0])

        const res = await axios.post(`${API_URL}/api/media`, {
            name: e.target.name.value,
            tier: e.target.tier.value,
            type: e.target.type.value,
            file: fileUrl
        })

        if (res.data) {
            e.target.reset()
            alert("Meme Added successfully")
        }
        else {
            alert("Something went wrong")
        }
    }

    return (
        <section className="memes-section p-4 flex justify-center items-center bg-slate-600 w-full">
            <div className='max-w-[449px] bg-slate-50 p-5 rounded shadow'>
                <form action="" onSubmit={handleSubmit} encType="multipart/form-data">
                    <div className="mb-4">
                        <h2 className='text-center text-xl'>Add New Meme</h2>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            Name
                        </label>
                        <input type="text" className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='name' />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            Tier
                        </label>
                        <select className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='tier'>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            File Type
                        </label>
                        <select className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='type' >
                            <option value="image">Image</option>
                            <option value="video">Video</option>
                        </select>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="" className='text-sm'>
                            Please choose an image or video
                        </label>
                        <input type="file" className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='file' />
                    </div>
                    <div className="mt-6">
                        <button className="w-full py-2 px-4 rounded shadow bg-teal-600 text-slate-50 text-lg">Add Meme</button>
                    </div>
                </form>
            </div>
        </section>
    )
}

export default AddNewMeme