import React, { useState, useContext, useEffect } from 'react'
import { SiteInfoContext } from '../../context/siteInfoContext'

const Tiers = () => {

    const [tierInfo, setTierInfo] = useState({ tier1: "4", tier2: "10", tier3: "20", tier4: "40", tier5: "60" })
    const { tier, updateTier } = useContext(SiteInfoContext)

    useEffect(() => {
        setTierInfo(tier)
    }, [tier])

    const handleClick = async () => {
        await updateTier(tierInfo)
        alert("Tier Updated")
    }

    return (
        <section className="buttons p-4 flex justify-center items-center bg-slate-600 w-full">
            <div className='max-w-[449px] bg-slate-50 p-5 rounded shadow'>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Tier 1 invite number
                    </label>
                    <input type="text" placeholder='' value={tierInfo.tier1} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='tier1' onChange={(e) => setTierInfo({ ...tierInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Tier 2 invite number
                    </label>
                    <input type="text" placeholder='' value={tierInfo.tier2} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='tier2' onChange={(e) => setTierInfo({ ...tierInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Tier 3 invite number
                    </label>
                    <input type="text" placeholder='' value={tierInfo.tier3} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='tier3' onChange={(e) => setTierInfo({ ...tierInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Tier 4 invite number
                    </label>
                    <input type="text" placeholder='' value={tierInfo.tier4} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='tier4' onChange={(e) => setTierInfo({ ...tierInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mb-4">
                    <label htmlFor="" className='text-sm'>
                        Tier 5 invite number
                    </label>
                    <input type="text" placeholder='' value={tierInfo.tier5} className='w-full py-2 pl-4 text-md rounded shadow outline-none bg-gray-200' name='tier5' onChange={(e) => setTierInfo({ ...tierInfo, [e.target.name]: e.target.value })} />
                </div>
                <div className="mt-6">
                    <button className="w-full py-2 px-4 rounded shadow bg-teal-600 text-slate-50 text-lg" onClick={handleClick}>Change Now</button>
                </div>
            </div>
        </section>
    )
}

export default Tiers