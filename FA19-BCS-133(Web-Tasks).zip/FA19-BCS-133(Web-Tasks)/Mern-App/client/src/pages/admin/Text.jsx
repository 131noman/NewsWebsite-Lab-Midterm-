import React, { useState, useEffect } from 'react'
import { useContext } from 'react'
import { SiteInfoContext } from '../../context/siteInfoContext'

const Text = () => {

    const [siteTextInfo, setSiteTextInfo] = useState({
        homePageText1: "", homePageText2: "", homePageText3: "", homePageText4: "", tier1Heading: "", tier1Subheading: "", tier2Heading: "", tier2Subheading: "", tier3Heading: "", tier3Subheading: "", tier4Heading: "", tier4Subheading: "", tier5Heading: "", tier5Subheading: "",

        tier1PageHeading: "", tier1PageSubheading: "",
        tier2PageHeading: "", tier2PageSubheading: "",
        tier3PageHeading: "", tier3PageSubheading: "",
        tier4PageHeading: "", tier4PageSubheading: "",
        tier5PageHeading: "", tier5PageSubheading: "",

        tierPageText1: "", tierPageText2: "", tierPageText3: "", tierPageNoAccess: ""
    })
    const { siteText, updateSiteText } = useContext(SiteInfoContext)

    const handleUpdateText = async () => {
        await updateSiteText(siteTextInfo)
        alert("Text Updated Successfully")
    }

    useEffect(() => {
        setSiteTextInfo(siteText)
    }, [siteText])

    return (
        <section className="buttons p-4 flex justify-center items-center bg-slate-600 w-full">
            <div className='max-w-[449px] bg-slate-50 p-5 rounded shadow'>
                <div className="p-3 bg-slate-300 mt-4">
                    <h2 className="text-lg">Home Page Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Text 1</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.homePageText1} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="homePageText1" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Text 2</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.homePageText2} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="homePageText2" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Text 3</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.homePageText3} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="homePageText3" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Text 4</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.homePageText4} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="homePageText4" />
                    </div>
                </div>
                <div className="p-3 bg-slate-300 mt-6">
                    <h2 className="text-lg">Tier List Page Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Tier 1 Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier1Heading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier1Heading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 1 Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier1Subheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier1Subheading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 2 Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier2Heading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier2Heading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 2 Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier2Subheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier2Subheading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 3 Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier3Heading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier3Heading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 3 Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier3Subheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier3Subheading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 4 Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier4Heading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier4Heading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 4 Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier4Subheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier4Subheading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 5 Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier5Heading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier5Heading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 5 Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier5Subheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier5Subheading" />
                    </div>
                </div>
                <div className="p-3 bg-slate-300 mt-6">
                    <h2 className="text-lg">Tier 1 Page Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Tier 1 Page Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier1PageHeading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier1PageHeading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 1 Page Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier1PageSubheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier1PageSubheading" />
                    </div>
                </div>
                <div className="p-3 bg-slate-300 mt-6">
                    <h2 className="text-lg">Tier 2 Page Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Tier 2 Page Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier2PageHeading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier2PageHeading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 2 Page Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier2PageSubheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier2PageSubheading" />
                    </div>
                </div>
                <div className="p-3 bg-slate-300 mt-6">
                    <h2 className="text-lg">Tier 3 Page Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Tier 3 Page Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier3PageHeading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier3PageHeading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 3 Page Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier3PageSubheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier3PageSubheading" />
                    </div>
                </div>
                <div className="p-3 bg-slate-300 mt-6">
                    <h2 className="text-lg">Tier 4 Page Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Tier 4 Page Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier4PageHeading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier4PageHeading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 4 Page Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier4PageSubheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier4PageSubheading" />
                    </div>
                </div>
                <div className="p-3 bg-slate-300 mt-6">
                    <h2 className="text-lg">Tier 5 Page Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Tier 5 Page Heading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier5PageHeading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier5PageHeading" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier 5 Page Subheading</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tier5PageSubheading} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tier5PageSubheading" />
                    </div>
                </div>
                <div className="p-3 bg-slate-300 mt-6">
                    <h2 className="text-lg">Tier Pages Texts</h2>
                    <div className="my-2">
                        <label htmlFor="">Tier Page Text 1</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tierPageText1} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tierPageText1" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier Page Text 2</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tierPageText2} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tierPageText2" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier Page Text 3</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tierPageText3} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tierPageText3" />
                    </div>
                    <div className="my-2">
                        <label htmlFor="">Tier Page No Access Text</label>
                        <input type="text" className='w-full py-1 pl-3 rounded outline-none border-1 border-slate-50 text-sm' value={siteTextInfo?.tierPageNoAccess} onChange={e => setSiteTextInfo({ ...siteTextInfo, [e.target.name]: e.target.value })} name="tierPageNoAccess" />
                    </div>
                </div>
                <div className="py-3 mt-6">
                    <button className='w-full bg-teal-600 text-white text-md text-center py-1' onClick={handleUpdateText}>Update Text</button>
                </div>
            </div>
        </section>
    )
}

export default Text