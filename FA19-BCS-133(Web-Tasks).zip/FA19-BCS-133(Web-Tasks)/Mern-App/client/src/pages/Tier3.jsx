import axios from 'axios'
import React, { useEffect, useState, useContext } from 'react'
import { AuthContext } from '../context/authContext'
import { ModalContext } from '../context/modalContext'
import { SiteInfoContext } from '../context/siteInfoContext'

const Tier3 = () => {

    const { currentUser } = useContext(AuthContext)
    const { setShowModal } = useContext(ModalContext)
    const { buttons, tier, API_URL, siteText } = useContext(SiteInfoContext)
    const [memes, setMemes] = useState([])
    const [page, setPage] = useState(0)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const getMemes = async () => {
            const res = await axios.get(`${API_URL}/api/media/forTier/3?skip=${page}&limit=5`, {
                headers: {
                    authorization: `Bearer ${currentUser.token}`
                }
            })
            setMemes(prev => [...prev, ...res.data])
            setLoading(false)
        }
        currentUser?.tier >= 3 && getMemes()
    }, [currentUser, page, API_URL])

    const handleScroll = () => {
        if (window.innerHeight + document.documentElement.scrollTop + 1 >= document.documentElement.scrollHeight) {
            setLoading(true)
            setPage(prev => prev + 5)
        }
    }

    useEffect(() => {
        window.addEventListener("scroll", handleScroll)

        return () => window.removeEventListener("scroll", handleScroll)
    }, [])


    return (
        <>
            <section className="my-2">
                <div className="container mx-auto px-3 md:px-0">
                    <div className="max-w-2xl w-full mx-auto">
                        {
                            currentUser?.tier < 3 && <>
                                <div className="no-access">
                                    <h1 className="text-3xl text-red-500 font-semibold py-2 px-6 rounded bg-gray-300 text-center">
                                        {siteText?.tierPageNoAccess}
                                    </h1>
                                    <div className="py-2 px-6 my-3 bg-gray-300 rounded text-center">
                                        <h2 className="text-xl">{siteText?.tier3PageHeading}</h2>
                                        <p className="text-md my-2">{siteText?.tier3PageSubheading}</p>
                                        <button onClick={() => setShowModal("invitation_link")} className=" bg-sky-600 text-white rounded-3xl py-1 px-6 mr-4">{buttons?.inviteButtonText}</button>
                                        <a href={buttons?.instantAccessButtonLink} target="_blank" rel='noreferrer' className="bg-pink-600 text-white rounded-3xl py-1 px-6">{buttons?.instantAccessButtonText}</a>
                                    </div>
                                    <div className='p-3 border-2 my-2'>
                                        <h2 className='text-2xl'>{currentUser?.username} {siteText?.tierPageText1} <span className='text-green-700 underline'>Tier 3</span> memes.</h2>
                                        <h2 className="text-xl my-1 p-1 bg-gray-200">{siteText?.tierPageText2} {currentUser?.invited} Invites</h2>
                                        <span className="text-xl">You need <span className="underline text-yellow-500">{tier?.tier3 - currentUser?.invited} more invites</span> {siteText?.tierPageText3}</span>
                                    </div>
                                </div>
                            </>
                        }
                        <div className="py-2 px-6 my-3 bg-gray-300 rounded text-center">
                            <h2 className="text-xl">{siteText?.tier3PageHeading}</h2>
                            <p className="text-md my-2">{siteText?.tier3PageSubheading}</p>
                        </div>
                        <div className="memes">
                            {
                                currentUser?.tier >= 3 && memes?.length && memes.map(meme => (
                                    <div className="bg-gray-200 p-3 rounded shadow my-2" key={meme._id}>
                                        {
                                            meme.type === "image" && <img className="w-full h-fit rounded" src={`${API_URL}/${meme.path + meme.url}`} alt={meme.name} />
                                        }
                                        {
                                            meme.type === "video" && <video src={`${API_URL}/${meme.path + meme.url}`} className="w-full h-fit rounded" controls></video>
                                        }
                                    </div>
                                ))
                            }
                            {
                                loading && <div className="text-center mx-auto w-[100px]">
                                    <button className='gap-2 w-[50px] h-[50px] rounded-full shadow-lg animate-spin  flex items-center justify-between flex-col '>
                                        <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                                        <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                                        <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                                        <span className='w-2 h-2 bg-slate-700 rounded-tl-xl rounded-br-xl'></span>
                                    </button>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Tier3