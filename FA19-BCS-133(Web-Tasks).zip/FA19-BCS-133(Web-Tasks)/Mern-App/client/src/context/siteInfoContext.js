import axios from "axios";
import { useState } from "react";
import { createContext, useEffect } from "react";

export const SiteInfoContext = createContext()

export const SiteInfoContextProvider = ({ children }) => {

    const [buttons, setButtons] = useState({})
    const [tier, setTier] = useState({})
    const [siteText, setSiteText] = useState({})
    const API_URL = "https://memerhub-online.onrender.com"
    // const API_URL = "http://localhost:5000"

    const updateButtons = async (updatedButtons) => {
        const res = await axios.put(`${API_URL}/api/siteInfo/buttons`, updatedButtons)
        setButtons(res.data)
        console.log(`Button ${res.data}`)
    }

    const updateTier = async (updateTiers) => {
        const res = await axios.put(`${API_URL}/api/siteInfo/tier`, updateTiers)
        setTier(res.data)
        console.log(`Tier  ${res.data}`);
    }

    const updateSiteText = async (updateTiers) => {
        const res = await axios.put(`${API_URL}/api/siteInfo/sitetext`, updateTiers)
        setSiteText(res.data)
    }

    useEffect(() => {
        const getButtons = async () => {
            const res = await axios.get(`${API_URL}/api/siteInfo/buttons`)
            if (res.data) {
                setButtons(res.data)
            }
        }
        const getTier = async () => {
            const res = await axios.get(`${API_URL}/api/siteInfo/tier`)
            if (res.data) {
                setTier(res.data)
            }
        }
        const getSiteText = async () => {
            const res = await axios.get(`${API_URL}/api/siteInfo/sitetext`)
            if (res.data) {
                setSiteText(res.data)
            }
        }
        getButtons()
        getTier()
        getSiteText()
    }, [])

    return (
        <SiteInfoContext.Provider value={{ buttons, updateButtons, tier, updateTier, API_URL, siteText, updateSiteText }}>
            {children}
        </SiteInfoContext.Provider>
    )
}