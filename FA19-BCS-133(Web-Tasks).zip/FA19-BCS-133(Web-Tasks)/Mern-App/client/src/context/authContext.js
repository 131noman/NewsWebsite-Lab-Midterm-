import axios from "axios"
import { useEffect, createContext, useState, useContext } from "react"
import { SiteInfoContext } from "./siteInfoContext"

export const AuthContext = createContext()

export const AuthContextProvider = ({ children }) => {


    const { API_URL } = useContext(SiteInfoContext)
    const [currentUser, setCurrentUser] = useState(JSON.parse(localStorage.getItem("invite_system_user")) || null)
    const [role, setRole] = useState(null)

    const login = async (inputs) => {
        const res = await axios.post(`${API_URL}/api/auth/login`, inputs)
        setCurrentUser(res.data)
        setRole(res?.data?.role === "admin" ? "admin" : null)
    }

    const logout = async (inputs) => {
        // await axios.post("http://localhost:8800/api/auth/logout")
        setCurrentUser(null)
    }

    const register = async (inputs) => {
        const res = await axios.post(`${API_URL}/api/auth/register`, inputs)
        setCurrentUser(res.data)
        setRole(res?.data?.role === "admin" ? "admin" : null)
    }

    useEffect(() => {
        localStorage.setItem("invite_system_user", JSON.stringify(currentUser))
        setRole(currentUser?.role)
    }, [currentUser])

    useEffect(() => {
        if (currentUser) {
            const getMe = async () => {
                const res = await axios.get(`${API_URL}/api/auth/getMe`, {
                    headers: {
                        authorization: `Bearer ${currentUser?.token}`
                    }
                })
                setCurrentUser(await res?.data?.message ? null : res?.data)
                setRole(await res?.data?.role === "admin" ? "admin" : null)
            }
            getMe()
        }
    }, [API_URL])

    return (
        <AuthContext.Provider value={{ currentUser, login, logout, register, role }}>
            {children}
        </AuthContext.Provider>
    )
}