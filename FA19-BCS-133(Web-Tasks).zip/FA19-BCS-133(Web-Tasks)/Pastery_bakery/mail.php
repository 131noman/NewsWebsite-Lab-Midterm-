<?php

require 'phpmailer/PHPMailerAutoload.php';

if(isset($_POST['submit'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // $mail->isSMTP(); (Commented because of live server)

    $mail = new PHPMailer;
    $mail->Host='smtp.gmail.com';
    $mail->Port=587;
    $mail->SMTPAuth=true;
    $mail->SMTPSecure='tls';

    $mail->Username='example@gmail.com';
    $mail->Password='passwordHere';

    $mail->setFrom('example@gmail.com','Example');
    $mail->addAddress('example@gmail.com');
    $mail->addReplyTo('example@gmail.com');

    $mail->isHTML(true);
    $mail->Subject='Visitor message from pastry.com';
    $mail->Body="<h4>Name: $name </h4
             
                     <h4>Email: $email </h4>
               
                     <h4> Message: $message </h4>
            ";

    if(!$mail->send()){
        echo "<script> alert('Sorry, Your Message cannot be sent. Please try again.'); </script>";
    }
    else{
        echo "<script> alert('Thanks! Your Message has been sent successfully. We will contact you soon.'); </script>";
    }
}

?>
